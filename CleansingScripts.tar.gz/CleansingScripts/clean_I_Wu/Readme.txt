I am using Hive to clean my data.
I simply read my csv file into Hive and choose the four interesting columns.
The screen shots are also attached.
